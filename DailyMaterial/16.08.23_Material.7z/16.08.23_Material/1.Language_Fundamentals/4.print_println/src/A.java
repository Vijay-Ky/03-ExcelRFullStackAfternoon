class A 
{
	public static void main(String[] args) 
	{
		System.out.println("print statment one");
		System.out.println("print statment two");
	}
}
