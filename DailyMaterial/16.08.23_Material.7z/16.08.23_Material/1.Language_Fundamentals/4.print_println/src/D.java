class D 
{
	public static void main(String[] args) 
	{
		System.out.print("print statement 1 \n");
		System.out.print("\t print statement 2 \n");
		System.out.println("\t print statement 3");
		System.out.print("\t print statement 4 \n");
		System.out.println("\t print statement 5");
	}
}
