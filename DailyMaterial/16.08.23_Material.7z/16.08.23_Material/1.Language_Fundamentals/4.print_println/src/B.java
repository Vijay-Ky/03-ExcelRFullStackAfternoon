class B 
{
	public static void main(String[] args) 
	{
		System.out.print("print statement one");
		System.out.print("print statement two");
	}
}
