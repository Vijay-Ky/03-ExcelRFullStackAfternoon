class B
{
	public static void main(String[] args) 
	{
		System.out.println(10 + 10);
		System.out.println(20 - 10);
		System.out.println(10 * 10);
		System.out.println(10 % 2);
		System.out.println(10 / 2);
	}
}
