class D 
{
	public static void main(String[] args) 
	{
		byte b             =                    -127;
		System.out.println(b);
	}
}
