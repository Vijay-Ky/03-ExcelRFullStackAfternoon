class F 
{
	public static void main(String[] args) 
	{
		char ch = 'a';
		System.out.println(ch);
		char ch2;
		System.out.println(ch2 = 'b');
		String s1;
		System.out.println(s1 = "abc");
		System.out.println(s1 = "xyz");
		System.out.println(s1);
	}
}
