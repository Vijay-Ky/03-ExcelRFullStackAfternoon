class C
{
	public static void main(String[] args) 
	{
		int i;
		i = 10;
		System.out.println(i);
		i = 20;
		System.out.println(i);
		i = 30;
		System.out.println(i);
		System.out.println(i);
		System.out.println(i);
		System.out.println(i);
		System.out.println(i);
		System.out.println(i);
		System.out.println(i);
		System.out.println(i);
	}
}

