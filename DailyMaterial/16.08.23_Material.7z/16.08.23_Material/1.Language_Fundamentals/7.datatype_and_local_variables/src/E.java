class E 
{
	public static void main(String[] args) 
	{
		byte b;
		short s = 100;
		int i = 200;
		long l = 1234;
		float f;
		double d = 20.2D;

		b = 20;
		f = 30.8f;

		System.out.println(b);
		System.out.println(s);
		System.out.println(i);
		System.out.println(l);
		System.out.println(f);
		System.out.println(d);
	}
}
