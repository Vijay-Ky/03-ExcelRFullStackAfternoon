class A 
{
	public static void main(String[] args) 
	{
		System.out.println(100 == 100);
		System.out.println(100 != 100);
		System.out.println(100 != 10);
		System.out.println(100 < 10);
		System.out.println(100 <= 10);
		System.out.println(10 > 100);
		System.out.println(100 >= 100);
		System.out.println(100 = 100);
	}
}
