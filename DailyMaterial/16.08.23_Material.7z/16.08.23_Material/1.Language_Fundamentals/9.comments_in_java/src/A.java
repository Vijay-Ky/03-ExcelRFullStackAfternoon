class A 
{
	public static void main(String[] args) 
	{
		//single line comment
		//comments are information/documentaion purpose
		//comments will be ignored by the compiler
		//for testing the code we can use comments
		System.out.println("Hello World!");
		//System.out.println("Hello World!");
	}
}

