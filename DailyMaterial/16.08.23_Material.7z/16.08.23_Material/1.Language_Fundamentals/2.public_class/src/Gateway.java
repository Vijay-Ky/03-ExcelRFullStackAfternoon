public class Gateway 
{
}
public class Grid
{
}
