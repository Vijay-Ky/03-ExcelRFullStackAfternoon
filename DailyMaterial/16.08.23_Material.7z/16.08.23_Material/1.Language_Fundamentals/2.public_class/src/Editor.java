class Encryption 
{
	public static void main(String[] args)
	{
		System.out.println("Encryption");
	}
}
class Endpoint 
{
	public static void main(String[] args)
	{
		System.out.println("Endpoint");
	}
}
class MyEvent 
{
	public static void main(String[] args)
	{
		System.out.println("MyEvent");
	}
}
class MyEnumeration 
{
	public static void main(String[] args)
	{
		System.out.println("MyEnumeration");
	}
}
class MyExpression 
{
}

