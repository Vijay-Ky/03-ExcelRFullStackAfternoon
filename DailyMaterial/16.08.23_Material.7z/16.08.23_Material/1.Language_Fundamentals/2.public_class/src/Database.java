class Database 
{
}
