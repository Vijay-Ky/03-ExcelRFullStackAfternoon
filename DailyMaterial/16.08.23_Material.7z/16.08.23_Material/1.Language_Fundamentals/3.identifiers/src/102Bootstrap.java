class 102Bootstrap 
{
	public static void main(String[] args) 
	{
		System.out.println(" from 102Bootstrap");
	}
}
