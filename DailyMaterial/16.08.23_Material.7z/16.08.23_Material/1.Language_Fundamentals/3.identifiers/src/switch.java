class switch 
{
	public static void main(String[] args) 
	{
		System.out.println("from switch");
	}
}
