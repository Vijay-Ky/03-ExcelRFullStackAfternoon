class null 
{
	public static void main(String[] args) 
	{
		System.out.println("from null");
	}
}
