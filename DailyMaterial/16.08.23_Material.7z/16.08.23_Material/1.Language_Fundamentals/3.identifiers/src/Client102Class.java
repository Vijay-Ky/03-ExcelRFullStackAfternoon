class Client102Class 
{
	public static void main(String[] args) 
	{
		System.out.println("from Client102Class");
	}
}
