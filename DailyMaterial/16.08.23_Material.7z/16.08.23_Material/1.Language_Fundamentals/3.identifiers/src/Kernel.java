class Kernel 
{
	public static void main(String[] args) 
	{
		System.out.println("from Kernal");
	}
}
