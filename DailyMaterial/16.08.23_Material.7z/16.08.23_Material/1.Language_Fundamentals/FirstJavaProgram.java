class FirstJavaProgram
{
    static public void main(String[] ref)
    {
       System.out.println("Hello World!");
    }
}